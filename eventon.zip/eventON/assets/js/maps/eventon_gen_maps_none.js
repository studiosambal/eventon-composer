/**
 * Gen maps function without anything
 * @version 4.9.6
 */
(function($){
	$.fn.evoGenmaps = function(opt){};

	$.fn.evo_load_gmap = function(opt){
		this.hide();
	}
}(jQuery));