<?php

/*
	Plugin Name: Real3D Flipbook PDF Viewer PRO
	Plugin URI: https://codecanyon.net/item/real3d-flipbook-wordpress-plugin/6942587
	Description: Premium Responsve Real 3D FlipBook & PDF Viewer
	Version: 4.12.0.1
	Author: creativeinteractivemedia
	Author URI: http://codecanyon.net/user/creativeinteractivemedia
	*/

define('REAL3D_FLIPBOOK_VERSION', '4.12.0.1');
define('REAL3D_FLIPBOOK_FILE', __FILE__);

include_once(plugin_dir_path(__FILE__) . '/includes/Real3DFlipbook.php');
